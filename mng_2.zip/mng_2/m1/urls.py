from django.urls import path
from . import views


urlpatterns = [
    path('register/', views.register, name='register'),
    path('student_forms/', views.student_forms, name='student_forms'),
    path('logout/', views.logout_user, name='logout_user'),
    path('teacher_login/', views.teacher_login_user, name='teacher_login'),
    path('student_login/', views.student_login_user, name='student_login'),
    path('home/', views.home, name='home'),
    path('student_register/', views.student_register.as_view(), name='student_register'),
    path('teacher_register/', views.teacher_register.as_view(), name='teacher_register'),
    path('student_forms/edit/<int:pk>/', views.edit_student, name='edit_student'),
    path('student_forms/delete/<int:pk>/', views.delete_student, name='delete_student'),
    path('students_details/', views.student_details, name='student_details'),

]