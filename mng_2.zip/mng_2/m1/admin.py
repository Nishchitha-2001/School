from django.contrib import admin
from .models import User, Student, Teacher, Student_data

# Register your models here.
admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(Student_data)

