from email import message
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout,authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.views.generic import CreateView
from .models import User,Student_data
from .forms import StudentSignUpForm, TeacherSignUpForm,StudentForm
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
# Create your views here.

def home(request):
    return render(request, 'home.html')

def register(request):
    return render(request, 'register.html')

class student_register(CreateView):
    model = User
    form_class = StudentSignUpForm
    template_name= 'student_register.html'

    def form_valid(self, form):
        user = form.data_save()
        login(self.request, user)
        return redirect('register.html')

class teacher_register(CreateView):
    model = User
    form_class = TeacherSignUpForm
    template_name='teacher_regsiter.html'

    def form_valid(self, form):
        user = form.data_save()
        login(self.request, user)
        return redirect('/m1/student_forms/')



def student_login_user(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_student:
                login(request, user)
                return redirect('/m1/students_details/')
            else:
                messages.error(request, "Invalid username or password")
        else:
            messages.error(request, "Invalid username or password")
    return render(request, 'student_login.html', context={'form': AuthenticationForm()})
def teacher_login_user(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None and user.is_teacher:
                login(request, user)
                return redirect('/m1/student_forms/')  # Redirect to appropriate URL
            else:
                messages.error(request, "Invalid username or password")
        else:
            messages.error(request, "Invalid username or password")
    else:
        form = AuthenticationForm()
    return render(request, 'teacher_login.html', {'form': form})
def student_forms(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)


            total_classes = 20
            attended_classes = form.cleaned_data.get('attendance', 0)


            attendance_percentage = (attended_classes / total_classes) * 100


            student.attendance = attendance_percentage


            student.save()


            if attendance_percentage < 75:
                subject = 'Low Attendance Warning'
                message = 'Your attendance is below 75%. Please make sure to attend classes regularly.'
                from_email = settings.EMAIL_HOST_USER
                recipient_list = [student.email]


                send_mail(subject, message, from_email, recipient_list)


                messages.info(request, 'An email has been sent regarding your low attendance.')


            students = Student_data.objects.all()
            return render(request, 'student_forms.html', {'form': form, 'students': students})
    else:
        form = StudentForm()

    students = Student_data.objects.all()
    return render(request, 'student_forms.html', {'form': form, 'students': students})


def student_details(request):
    students = Student_data.objects.all()
    return render(request,'students_details.html', {'students': students})
def edit_student(request, pk):
    student = get_object_or_404(Student_data, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('/m1/student_forms/')
    else:
        form = StudentForm(instance=student)
    return render(request, 'edit_student.html', {'form': form})

def delete_student(request, pk):
    student = get_object_or_404(Student_data, pk=pk)
    if request.method == 'POST':
        student.delete()
        return redirect('/m1/student_forms/')
    return redirect('/m1/student_forms/')
def logout_user(request):
    logout(request)
    return redirect('/m1/home')
