from django.apps import AppConfig


class M1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'm1'
