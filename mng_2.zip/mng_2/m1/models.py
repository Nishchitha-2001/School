from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.



class User(AbstractUser):
    is_student = models.BooleanField(default=False)
    is_teacher = models.BooleanField(default=False)
    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80)

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    phone_number = models.CharField(max_length=10)
    class_name = models.CharField(max_length=100)

class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    phone_number = models.CharField(max_length=10)
    department = models.CharField(max_length=30)

class Student_data(models.Model):
    roll_number = models.CharField(primary_key=True, max_length=20)
    name = models.CharField(max_length=100)
    subject1_marks = models.IntegerField()
    subject2_marks = models.IntegerField(null=True, blank=True)
    subject3_marks = models.IntegerField(null=True, blank=True)
    subject4_marks = models.IntegerField(null=True, blank=True)  # New field for subject 4 marks
    subject5_marks = models.IntegerField(null=True, blank=True)  # New field for subject 5 marks
    # present_or_absent = models.BooleanField(default=False)  # Field for present or absent
    email = models.EmailField(max_length=254, null=True, blank=True)
    attendance = models.IntegerField(null=True,blank=True)# New field for email ID

    def __str__(self):
        return self.name

